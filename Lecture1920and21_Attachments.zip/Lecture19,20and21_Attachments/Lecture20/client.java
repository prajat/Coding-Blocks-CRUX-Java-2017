package Lecture20;

public class client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Trie trie = new Trie();

		trie.add("art");
		trie.add("arts");
		trie.add("bug");
		trie.add("boy");
		trie.add("see");
		trie.add("sea");
		trie.add("seen");

		//trie.display();
		
		System.out.println(trie.search("artist"));
		System.out.println("*****************");
		trie.remove("art");
		trie.display();
		System.out.println("*****************");
		trie.remove("arts");
		trie.display();
		
//		trie.displayAll("ar");
	}

}

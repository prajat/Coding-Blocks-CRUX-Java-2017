package Lecture12.IStory;

public interface IEngine {
	void start();

}

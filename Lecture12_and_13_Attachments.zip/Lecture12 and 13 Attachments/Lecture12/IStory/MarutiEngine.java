package Lecture12.IStory;

public class MarutiEngine implements IEngine {

	@Override
	public void start() {
		// TODO Auto-generated method stub
		System.out.println("Maruti Starts");
	}



}

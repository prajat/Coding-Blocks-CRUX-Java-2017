package Lecture12.IStory;

public class HyundaiEngine implements IEngine {

	

	@Override
	public void start() {
		// TODO Auto-generated method stub
		System.out.println("Hyundai starts");
	}

}

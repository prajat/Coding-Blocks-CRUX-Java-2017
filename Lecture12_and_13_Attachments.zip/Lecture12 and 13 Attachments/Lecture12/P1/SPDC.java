package Lecture12.P1;

public class SPDC extends C{
	public void Fun(){
		// pvt missing
		
	}
}

package Lecture12.P1;

public class C {
	public int d1;
	protected int d2;
	int d3 = 10;
	private int d4;

	public void Fun() {
		// all visible
		
	}
}

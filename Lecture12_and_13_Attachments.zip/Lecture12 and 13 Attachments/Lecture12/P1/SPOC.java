package Lecture12.P1;

public class SPOC {
	public void Fun() {
		C obj = new C();
		// pvt missing
		
	}
}

package Lecture12.P2;

import Lecture12.P1.C;

public class OPOC {
	public void Fun() {
		C obj = new C();
		// only public visible

	}

}

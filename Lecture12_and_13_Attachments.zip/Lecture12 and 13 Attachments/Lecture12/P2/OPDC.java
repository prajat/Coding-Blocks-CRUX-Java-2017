package Lecture12.P2;

import Lecture12.P1.C;

public class OPDC extends C {
	

	public void Fun() {
		// friendly and pvt missing
		
	}
}

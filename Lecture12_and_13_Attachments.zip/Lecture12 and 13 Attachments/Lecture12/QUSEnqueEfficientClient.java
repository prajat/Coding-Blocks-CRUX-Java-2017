package Lecture12;

public class QUSEnqueEfficientClient {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		QUSEnqueEfficient queue = new QUSEnqueEfficient();
		for (int i = 1; i <= 5; i++) {
			queue.enqueue(i);
		}
		queue.display();
		System.out.println(queue.dequeue());
		 queue.display();
	}

}

package Lecture12;

import Lecture11.DynamicStack;

public class QUSEnqueEfficient {
	private DynamicStack sPrimary;
	private DynamicStack sSecondary;

	public QUSEnqueEfficient() throws Exception {
		// TODO Auto-generated constructor stub
		sPrimary = new DynamicStack();
		sSecondary = new DynamicStack();
	}

	public int size() {
		return this.sPrimary.size();
	}

	public boolean isEmpty() {
		return this.size() == 0;
	}

	public void enqueue(int item) throws Exception {
		this.sPrimary.push(item);
	}

	public int dequeue() throws Exception {
		if (this.size() == 0) {
			throw new Exception("Queue is Empty");
		}

		while (!(this.sPrimary.size() == 1)) {
			sSecondary.push(sPrimary.pop());
		}
		int rv = this.sPrimary.pop();
		while (!this.sSecondary.isEmpty()) {
			sPrimary.push(sSecondary.pop());
		}

		return rv;
	}

	public int front() throws Exception {
		if (this.size() == 0) {
			throw new Exception("Queue is Empty");
		}

		while (!(this.sPrimary.size() == 1)) {
			sSecondary.push(sPrimary.pop());
		}
		int rv = this.sPrimary.pop();
		sSecondary.push(rv);
		while (!this.sSecondary.isEmpty()) {
			sPrimary.push(sSecondary.pop());
		}

		return rv;
	}

	public void display() throws Exception {
		reverseStack(this.sPrimary, new DynamicStack(), 0);
		this.sPrimary.display();
		reverseStack(this.sPrimary, new DynamicStack(), 0);

	}

	private void reverseStack(DynamicStack stack, DynamicStack helper, int index) throws Exception {
		if (stack.isEmpty()) {
			return;
		}
		int item = stack.pop();
		reverseStack(stack, helper, index + 1);
		helper.push(item);
		if (index == 0) {
			while (!helper.isEmpty()) {
				stack.push(helper.pop());
			}
		}
	}
}

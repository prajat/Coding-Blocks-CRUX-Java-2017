package Lecture15;

public class client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 50 3 46 2 16 0 29 0 10 0 38 1 89 0
		GenericTree tree = new GenericTree();
		tree.display();
		System.out.println(tree.size2());
		System.out.println(tree.max());
		System.out.println(tree.height());
		System.out.println(tree.find(29));
		// tree.mirror();
		// tree.display();
		tree.printAtLevel(1);
		System.out.println("*****Pre*****");
		tree.preOrder();
		System.out.println("****Post*****");
		tree.postOrder();
		System.out.println("Level Order");
		tree.levelOrder();
	}

}

package Lecture13;

public class client {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		LinkedList list = new LinkedList();
		list.addFirst(20);
		list.addFirst(10);
		list.addLast(30);
		list.addLast(40);
		list.addLast(50);
		list.addLast(60);
		// list.addAt(55, 5);

		list.display();
		// System.out.println(list.getFirst());
		// System.out.println(list.getLast());
		// System.out.println(list.getAt(3));

		// list.removeAt(3);
		//
		// list.display();

		list.reversePR();
		list.mergeSort();
		list.display();
		// LinkedList other = new LinkedList();
		// other.addLast(25);
		// other.addLast(35);
		// other.addLast(45);
		// System.out.println(list.mid());
		// System.out.println(list.kthNodeFromEnd(3));
		//
		// LinkedList sorted = list.merge(other);
		// sorted.display();

		// Add(null);
	}

	public static void Add(Integer obj) {
		System.out.println("Hi");
	}

	// public static void Add(Object obj) {
	// System.out.println("object");
	// }

	public static void Add(String obj) {
		System.out.println("String");
	}

}

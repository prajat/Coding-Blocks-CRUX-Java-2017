package Lecture13.Generics;

// Superior vis-a-vis RawPair
// Reusability - solved, set - solved, get - solved
public class Pair<T> {
	T one;
	T two;
}

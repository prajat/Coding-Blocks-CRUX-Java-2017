package Lecture13.Generics;

// SOLUTION 1
// Reusability solved, but gets are inconvenient and dangerous
public class RawPair {
	Object one;
	Object two;
}

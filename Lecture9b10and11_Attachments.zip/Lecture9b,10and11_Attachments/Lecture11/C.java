package Lecture11;

public class C extends P {
	int d2 = 21;
	int d = 22;


	public static int NUMBER = 20;

	public void Fun2() {
		System.out.println("Inside C's Fun2");
	}

	public void Fun() {
		System.out.println("Inside C's Fun");
	}

	// @Override
//	public void finalFun() {
//		System.out.println("Inside C's finaFun");
//	}

	public static void staticFun() {
		System.out.println("Inside C's staticFun.");
	}
}

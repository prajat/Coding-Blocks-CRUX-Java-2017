package Lecture11;

public class CA extends PA {
	public  int num=20;
	
//	public void Fun() {
//		System.out.println("Inside CA's Fun");
//	}

	public void Fun2() {
		System.out.println("Inside CA's Fun2.");
	}
}

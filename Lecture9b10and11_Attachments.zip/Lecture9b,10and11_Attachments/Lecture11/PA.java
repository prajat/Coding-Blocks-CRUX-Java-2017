package Lecture11;

public abstract class PA {
	public int num=10;
	public void Fun1() {
		System.out.println("Inside PA's Fun1.");
	}

	public void Fun(){
		
	}
}

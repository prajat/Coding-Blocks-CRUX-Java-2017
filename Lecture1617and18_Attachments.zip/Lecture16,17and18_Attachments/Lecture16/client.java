package Lecture16;

public class client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 18 true 19 true 14 false false true 74 false false true 91 true 39  false false false
		// 50 true 25 true 12 false false true 37 false true 49 false false true 75 true 62 true 55 false false false true 87 false false
		BinaryTree tree = new BinaryTree();
		tree.display();

		System.out.println(tree.Size2());
		System.out.println(tree.Height());
		System.out.println(tree.Max());
		System.out.println(tree.Find(91));
		tree.inOrder();
		System.out.println();
		tree.preOrderIterative();
		System.out.println();
	//	System.out.println(tree.lca(19, 91));

		System.out.println(tree.isBST());

	}

}

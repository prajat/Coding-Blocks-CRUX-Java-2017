package Lecture18;

public class client {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		HashTable<String, Integer> map = new HashTable<>(4);
		map.put("USA", 200);
		map.put("Russia", 250);
		map.put("India", 225);
		map.display();
		map.put("China", 300);
		map.display();
//		map.put("RSA", 150);
//		map.put("Nepal", 50);
//		map.put("Bhutan", 25);

//		map.display();
//		map.put("India", 275);
//		map.display();
//		System.out.println(map.get("USA"));
//		System.out.println(map.get("Pak"));
//		
//		System.out.println(map.remove("USA"));
		
		map.display();
		
		

	}

}

package Multithreading;

public class client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MTDemo obj = new MTDemo();

//		 PrintTable pt=new PrintTable();
//		
//		 Thread1 obj1 = new Thread1(pt);
//		 Thread2 obj2 = new Thread2(pt);
//		
//		 obj1.setName("t1 thread");
//		 obj2.setName("t2 thread");
//		
//		 obj1.start();
//		 obj2.start();

	}

}

package Multithreading;

public class PrintTable {

	public synchronized void printTable() {
		for (int i = 1; i <= 1000; i++) {
			System.out.println(i);
		}
	}

}

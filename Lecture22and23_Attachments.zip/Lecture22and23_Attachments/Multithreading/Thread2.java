package Multithreading;

public class Thread2 extends Thread {
	PrintTable pt;

	Thread2(PrintTable pt) {
		this.pt = pt;
	}

	public void run() {
		pt.printTable();
	}

}

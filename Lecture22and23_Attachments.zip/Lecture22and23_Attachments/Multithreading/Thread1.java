package Multithreading;

public class Thread1 extends Thread {
	PrintTable pt;

	Thread1(PrintTable pt) {
		this.pt = pt;
	}

	public void run() {
		pt.printTable();
	}
	

}

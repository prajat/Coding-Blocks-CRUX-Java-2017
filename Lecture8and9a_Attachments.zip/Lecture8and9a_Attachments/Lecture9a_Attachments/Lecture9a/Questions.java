package Lecture9a;

public class Questions {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// int[] one = { 1, 7, 8, 9, 15 };
		// int[] two = { 2, 10, 18, 24 };
		// int[] ans = merge(one, two);
		// for (int i = 0; i < ans.length; i++) {
		// System.out.println(ans[i]);
		// }

		// int[] arr = { 6, 1, 4, 3, 7, 2 };
		// int[] ans = mergeSort(arr, 0, arr.length - 1);
		// for (int i = 0; i < ans.length; i++) {
		// System.out.println(ans[i]);
		// }

		int[] arr = { 10, 80, 30, 90, 50, 70 };
		quicksort(arr, 0, arr.length - 1);
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}
	}

	public static int[] merge(int[] one, int[] two) {
		int[] sorted = new int[one.length + two.length];
		int i = 0, j = 0, k = 0;
		while (i < one.length && j < two.length) {
			if (one[i] < two[j]) {
				sorted[k] = one[i];
				i++;
				k++;
			} else {
				sorted[k] = two[j];
				j++;
				k++;
			}
		}
		while (i < one.length) {
			sorted[k] = one[i];
			i++;
			k++;
		}

		while (j < two.length) {
			sorted[k] = two[j];
			j++;
			k++;
		}

		return sorted;
	}

	public static int[] mergeSort(int[] arr, int low, int high) {
		if (low == high) {
			int[] baseResult = new int[1];
			baseResult[0] = arr[low];
			return baseResult;
		}
		int mid = (low + high) / 2;
		int[] fhalf = mergeSort(arr, low, mid);
		int[] shalf = mergeSort(arr, mid + 1, high);
		int[] ans = merge(fhalf, shalf);

		return ans;
	}

	public static void quicksort(int[] arr, int low, int high) {
		if (low >= high) {
			return;
		}

		int left = low, right = high;
		int mid = (left + right) / 2;
		int pivot = arr[mid];
		while (left <= right) {
			while (arr[left] < pivot) {
				left++;
			}
			while (arr[right] > pivot) {
				right--;
			}
			if (left <= right) {
				int temp = arr[left];
				arr[left] = arr[right];
				arr[right] = temp;
				left++;
				right--;
			}
		}
		quicksort(arr, low, right);
		quicksort(arr, left, high);
	}
}

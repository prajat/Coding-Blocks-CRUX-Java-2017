package Lecture2;

import java.util.Scanner;

public class FunWithQuestions {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int bin = 100000;
		System.out.println(binToDec(bin));
		System.out.println(decToBin(32));
		System.out.println(AnyToDec(2, 100000));
		System.out.println(DecToAny(2, 32));
		System.out.println(AnyToAny(37, 8, 2));
		System.out.println(log(32, 2));
		System.out.println(inv(3214));

		Scanner s = new Scanner(System.in);
		char ch = s.next().charAt(0);
		System.out.println(ch);

	}

	public static int binToDec(int bin) {
		int dec = 0;
		int twopowers = 1;
		while (bin != 0) {
			int rem = bin % 10;
			dec = dec + rem * twopowers;
			twopowers = twopowers * 2;
			bin = bin / 10;

		}
		return dec;

	}

	public static int decToBin(int dec) {
		int bin = 0;
		int tenpowers = 1;
		while (dec != 0) {
			int rem = dec % 2;
			bin = bin + rem * tenpowers;
			tenpowers = tenpowers * 10;
			dec = dec / 2;

		}
		return bin;
	}

	public static int AnyToDec(int sb, int num) {
		int dec = 0;
		int sbpowers = 1;
		while (num != 0) {
			int rem = num % 10;
			dec = dec + rem * sbpowers;
			sbpowers = sbpowers * sb;
			num = num / 10;

		}
		return dec;
	}

	public static int DecToAny(int db, int dec) {
		int ans = 0;
		int tenpowers = 1;
		while (dec != 0) {
			int rem = dec % db;
			ans = ans + rem * tenpowers;
			tenpowers = tenpowers * 10;
			dec = dec / db;

		}
		return ans;
	}

	public static int AnyToAny(int num, int sb, int db) {
		int dec = AnyToDec(sb, num);
		int ans = DecToAny(db, dec);
		return ans;
	}

	public static int log(int x, int n) {
		int counter = 0;
		while (x != 1) {
			counter++;
			x = x / n;
		}
		return counter;
	}

	public static int inv(int num) {
		int inv = 0;
		int pow = 1;
		int counter = 1;
		while (num != 0) {
			pow = 1;
			int rem = num % 10;
			while (rem != 1) {
				pow = pow * 10;
				rem--;
			}
			inv = inv + pow * counter;
			counter++;
			num = num / 10;
		}
		return inv;
	}

}

package Lecture2;

import java.util.Scanner;

public class Pattern2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		int n = s.nextInt();
		int row = 1;
		int col = 1;
		int len = 2 * n - 1;
		int value = n;
		int decvalues = 0;
		while (row <= len) {
			int samevalues = len - (2 * decvalues);
			value = n;
			col = 1;
			while (col <= decvalues) {
				System.out.print(value+" ");
				value--;
				col++;
			}
			col = 1;
			while (col <= samevalues) {
				System.out.print(value+" ");
				col++;
			}
			value++;
			col=1;
			while (col <= decvalues) {
				System.out.print(value+" ");
				value++;
				col++;
			}
			if (row < n) {
				decvalues++;
			} else {
				decvalues--;
			}
			System.out.println();
			row++;
		}

	}

}

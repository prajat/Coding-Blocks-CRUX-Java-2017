package Lecture2;

public class FtoC {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int fmin = 00, fmax = 300;
		int fcurrent = fmin;
		int c = 0;
		int step = 20;
		while (fcurrent <= fmax) {
			c = (int)((5.0 / 9) * (fcurrent - 32));
			System.out.println(fcurrent + "\t" + c);
			fcurrent = fcurrent + step;
		}

	}

}
